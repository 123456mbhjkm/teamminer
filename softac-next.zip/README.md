This is a [Next.js](https://nextjs.org/) project 

## Softec Next js Project 

 

```bash
 them pure 
```
